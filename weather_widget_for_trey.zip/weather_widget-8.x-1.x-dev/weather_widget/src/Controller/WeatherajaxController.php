<?php


/**
 * @file
 * Contains \Drupal\weather_widget\Controller\WeatherajaxController.
 */

namespace Drupal\weather_widget\Controller;

use Drupal\Core\Controller\ControllerBase;
use \Symfony\Component\HttpFoundation\Response;




/**
 * Class WeatherajaxController.
 */

class WeatherajaxController extends ControllerBase {

/**
 * Return weather status list
 * @param  $lat      Latitude
 * @param  $lng      Longitude
 * @param  $language Language of weather status list
 */
public function ww_get_weather_list($lat,$lng,$language){

  $config = $config = \Drupal::config('weather_widget.configuration');
  $uri = 'http://api.openweathermap.org/data/2.5/forecast/daily?lat='.$lat.'&lon='.$lng.'&appid='.$config->get('openweathermap_api').'&lang='.$language.'&units='.$config->get('weather_widget_units').'';

    try {
    $response = \Drupal::httpClient()->get($uri, array('headers' => array('Accept' => 'text/plain')));
    $data = (string) $response->getBody();
    $data = json_decode($data);
    if (empty($data)) {
      return FALSE;
    }
    return $data->list;
  }
  catch (RequestException $e) {
    return FALSE;
  }

}


/**
 * Return weather city name
 * @param  $lat      Latitude
 * @param  $lng      Longitude
 * @param  $language Language of weather status list
 */
public function ww_get_city_by_latlng($lat,$lng,$language){

  $config = $config = \Drupal::config('weather_widget.configuration');
  $uri = 'https://maps.googleapis.com/maps/api/geocode/json?latlng='.$lat.','.$lng.'&key='.$config->get('weather_google_api').'&language='.$language.'';
  try {
    $response = \Drupal::httpClient()->get($uri, array('headers' => array('Accept' => 'text/plain')));
    $data = (string) $response->getBody();
    $data = json_decode($data);
    if (empty($data)) {
      return FALSE;
    }
    $items = array();
    if ($data->status == 'OK'){
      foreach($data->results[0]->address_components as $object){
        if($object->types[0] == 'locality' && $object->types[1] == 'political'){
          $items['city'] =  $object->long_name;
        } 
        else if($object->types[0] == 'country' && $object->types[1] == 'political'){
          $items['country'] =  $object->long_name;
        } 
      }
    }
    return $items;
  }
  catch (RequestException $e) {
    return FALSE;
  }

}



public function build() {


    $image_url = file_create_url(drupal_get_path('module', 'weather_widget') . '/assets/images/weather-widget.jpg');
    $lat = $_POST['lat'];
    $lng = $_POST['lng'];
    $default_langcode = \Drupal::languageManager()->getCurrentLanguage()->getId();
    $info = $this->ww_get_city_by_latlng($lat,$lng,$default_langcode);
    $items = $this->ww_get_weather_list($lat,$lng,$default_langcode);

   $build = array(
    '#theme'  => 'weather_ajax_block',
    '#items'  => $items,
    '#info'   => $info,
    '#image'  => $image_url,
   
    
    

    );
   return new Response(render($build));
 }

}
