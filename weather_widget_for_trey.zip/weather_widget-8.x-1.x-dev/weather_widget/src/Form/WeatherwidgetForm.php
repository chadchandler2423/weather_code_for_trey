<?php

namespace Drupal\weather_widget\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Class WeatherwidgetForm.
 */
class WeatherwidgetForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'weather_widget.configuration',
    ];
  }
  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'weather_widget_admin_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    
    
    $config = $this->config('weather_widget.configuration');

    $form['weather_widget_settings'] = [
      '#type'  => 'details',
      '#open'  => TRUE,
      '#title' => $this->t('Weather Widget settings'),
    ];
    $form['weather_widget_settings']['weather_widget_units'] = [
      '#type'  => 'select',
      '#title' => $this->t('Weather widget units format'),
      '#options' => array(
      'metric' => t('Celsius'),
      'imperial' => t('Fahrenheit'),
    ),
      '#default_value' => $config->get('weather_widget_units'),
      
    ];

    $form['weather_widget_settings']['openweathermap_api'] = [
      '#type'  => 'textfield',
      '#open'  => TRUE,
      '#title' => $this->t('openweathermap API key'),
      '#description' => $this->t('Requires openweathermap API key, https://openweathermap.org/api'),
      '#default_value' => $config->get('openweathermap_api'),
      

    ];

    $form['weather_widget_settings']['weather_google_api'] = [
      '#type'  => 'textfield',
      '#open'  => TRUE,
      '#title' => $this->t('Google API key.'),
      '#description' => $this->t('Requires Google API key.'),
      '#default_value' => $config->get('weather_google_api'),
      

    ];
  
    return parent::buildForm($form, $form_state);
  }


  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
 
  public function submitForm(array &$form, FormStateInterface $form_state) {
      parent::submitForm($form, $form_state);
     
      $config = $this->config('weather_widget.configuration');

      $config->set('weather_widget_units', $form_state->getValue('weather_widget_units'));
      $config->set('openweathermap_api', $form_state->getValue('openweathermap_api'));
      $config->set('weather_google_api', $form_state->getValue('weather_google_api'));

      $config->save();



  }



}
