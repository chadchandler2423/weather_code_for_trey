<?php

namespace Drupal\weather_widget\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a 'WeatherBlock' block.
 *
 * @Block(
 *  id = "weather_block",
 *  admin_label = @Translation("Weather widget block"),
 * )
 */



class WeatherBlock extends BlockBase {

  
   public function build() {

   	$image_url = file_create_url(drupal_get_path('module', 'weather_widget') . '/assets/images/weather-widget.jpg');

   return array(
    '#theme'  => 'weather_block',
    '#image'  => $image_url,
    '#attached' => [
        'library' => [
          'weather_widget/weather-widget-style',
          'weather_widget/weather-widget-style_rtl',
        ],
      ],

    );

 }

}
